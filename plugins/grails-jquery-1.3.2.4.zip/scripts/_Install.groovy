//
// This script is executed by Grails after plugin was installed to project.
// This script is a Gant script so you can use all special variables provided
// by Gant (such as 'baseDir' which points on project base dir). You can
// use 'Ant' to access a global instance of AntBuilder
//
// For example you can create directory under project tree:
// Ant.mkdir(dir:"/Users/nebolsin/Projects/grails-jquery/grails-app/jobs")
//

Ant.property(environment:"env")
grailsHome = Ant.antProject.properties."env.GRAILS_HOME"

includeTargets << grailsScript("Init")
checkVersion()
configureProxy()

// Hard coded for installation purpose
def jQueryVersion = '1.3.2'
def jQuerySources = 'jquery'

Ant.sequential {
    event("StatusUpdate", ["Downloading JQuery ${jQueryVersion}"])
     
    def files = ["jquery-${jQueryVersion}.js", "jquery-${jQueryVersion}.min.js"]

    mkdir(dir:"${basedir}/web-app/js/${jQuerySources}")
    files.each {
        get(dest:"${basedir}/web-app/js/${jQuerySources}/${it}",
            src:"http://jqueryjs.googlecode.com/files/${it}",
            verbose:true)
    }
}
event("StatusFinal", ["JQuery ${jQueryVersion} installed successfully"])

