package org.codehaus.groovy.grails.plugins.jquery
/**
 *
 * @author craigjones Jul 16, 2008
 */
class JQuery {
}
