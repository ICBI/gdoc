class Tag { 
	String name
}
