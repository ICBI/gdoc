class TagTests extends GroovyTestCase {

    void testSomething() {

    }
}