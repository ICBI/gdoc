class TaggingTests extends GroovyTestCase {

    void testSomething() {

    }
}