/**
 * User: SimonLei
 * Date: 2007-12-3
 * Time: 8:23:01
 */

interface Taggable {
}
